public class Pelanggan {

  // TODO: Tambahkan modifier
  private String nama;
  private int uang;
  private Order[] keranjang = new Order[1];
  private int kapasitasKeranjang = 5000;
  private int banyakBarang;

  // TODO: Buat Constructor
  public Pelanggan(String nama, int uang, int kapasitas) {
    this.nama = nama;
    this.uang = uang;
    this.banyakBarang = kapasitas;
  }

  // TODO: lengkapi method di bawah ini
  String addBarang(Barang barang, int banyakBarang) {
    boolean isExist = false;
    Order selectedKeranjang = null;
    int banyakAwal = banyakBarang;
    boolean isTooMuch = false;
    int weight = barang.getBeratBarang() * banyakBarang;
    if (barang.isStockReady(banyakBarang)) {
      this.decrementKapasitas(weight);
      while (this.kapasitasKeranjang <= 0) {
        banyakBarang--;
        this.kapasitasKeranjang += barang.getBeratBarang();

      }
      if (keranjang.length == 1) {
        keranjang[keranjang.length - 1] = new Order(barang, banyakBarang);
      } else {

        for (int i = 0; i < keranjang.length; i++) {
          if (keranjang[i].getBarang().getNama().equals(barang.getNama())) {
            isExist = true;
            selectedKeranjang = keranjang[i];
          }
        }
        if (isExist) {
          selectedKeranjang.setBanyakBarang(selectedKeranjang.getBanyakBarang() + banyakBarang);
        } else {
          keranjang = enlargeList(keranjang);
          keranjang[keranjang.length - 1] = new Order(barang, banyakBarang);
        }
      }

      return isTooMuch
          ? "Maaf " + banyakAwal + " " + barang.getNama() + " terlalu berat, tetapi " + banyakBarang + " "
              + barang.getNama() + " berhasil ditambahkan"
          : this.nama + " berhasil menambahkan " + banyakBarang + " " + barang.getNama();
    } else {
      return "Stock " + barang.getNama() + " kurang";
    }
  }

  // TODO: lengkapi method di bawah ini
  int totalHargaBarang() {
    int res = 0;
    for (int i = 0; i < keranjang.length; i++) {
      res += keranjang[i].getBanyakBarang() * keranjang[i].getBarang().getHarga();
    }
    return res;
  }

  // TODO: lengkapi method di bawah ini
  String cekUang() {
    return Integer.toString(this.uang);
  }

  // Setter and Getter dan lengkapi modifier
  String getNama() {
    return this.nama;
  }

  void setNama(String nama) {
    this.nama = nama;
  }

  int getUang() {
    return this.uang;
  }

  void setUang(int uang) {
    this.uang = uang;
  }

  Order[] getKeranjang() {
    return keranjang;
  }

  void decrementKapasitas(int bobot) {
    this.kapasitasKeranjang -= bobot;
  }

  Order[] enlargeList(Order[] arr) {
    // Source: https://stackoverflow.com/questions/8438879/expanding-an-array
    // set new temp playlist with enlarged size
    Order[] tempArr = new Order[arr.length + 1];
    // copy the entire arr to temp_arr
    System.arraycopy(arr, 0, tempArr, 0, arr.length);
    // set new reference for arr
    return tempArr;
  }
}
