public class Pelanggan {

  // TODO: Tambahkan modifier
  private String nama;
  private int uang;
  private Order[] keranjang = new Order[1];
  private int kapasitasKeranjang = 5000;

  public Pelanggan(String nama, int uang) {
    this.nama = nama;
    this.uang = uang;
  }

  String addBarang(Barang barang, int banyakBarang) {
    boolean isExist = false;
    Order selectedKeranjang = null;
    int banyakAwal = banyakBarang;
    boolean isTooMuch = false;
    // get the weight, multiply single barang weight with amount barang
    int weight = barang.getBeratBarang() * banyakBarang;

    // call method is stock ready from barang to get the info if barang ready?
    if (barang.isStockReady(banyakBarang)) {
      // call method decrement capacity
      this.decrementKapasitas(weight);
      // this while algorithm is to get the sufficient amount of barang
      while (this.kapasitasKeranjang < 0) {
        // while kapasitas keranjang still less than 0 then try to decrement the banyak barang
        banyakBarang--;
        // then add kapasitas with single berat barang
        this.kapasitasKeranjang += barang.getBeratBarang();
        // if this while is running means kapasitas is less than zero then set is too much to true
        isTooMuch = true;
      }
      // if first index null means empty
      if (keranjang[0] == null) {
        keranjang[keranjang.length - 1] = new Order(barang, banyakBarang);
      } else {
        // for every item in keranjang
        for (int i = 0; i < keranjang.length; i++) {
          // if barang is found then is exist true
          if (keranjang[i].getBarang().getNama().equals(barang.getNama())) {
            isExist = true;
            selectedKeranjang = keranjang[i];
          }
        }
        if (isExist) {
          // is exist then add banyak barang
          selectedKeranjang.setBanyakBarang(
            selectedKeranjang.getBanyakBarang() + banyakBarang
          );
        } else {
          // if not exist then create one
          keranjang = enlargeList(keranjang);
          keranjang[keranjang.length - 1] = new Order(barang, banyakBarang);
        }
      }
      // reduce barang
      barang.setStock(barang.getStock() - banyakBarang);
      // if too much then return "maaf ....", else return berhasil ditambahkan
      return isTooMuch
        ? "Maaf " +
        banyakAwal +
        " " +
        barang.getNama() +
        " terlalu berat, tetapi " +
        banyakBarang +
        " " +
        barang.getNama() +
        " berhasil ditambahkan"
        : this.nama +
        " berhasil menambahkan " +
        banyakBarang +
        " " +
        barang.getNama();
    } else {
      // if requested stock > stock available then return kurang
      return "Stock " + barang.getNama() + " kurang";
    }
  }

  int totalHargaBarang() {
    // keranjang 0 means empty then return 0
    int res = 0;
    if (keranjang[0] == null) {
      return 0;
    }
    // iterate every keranjang item multiply amount * harga
    for (int i = 0; i < keranjang.length; i++) {
      res +=
        keranjang[i].getBanyakBarang() * keranjang[i].getBarang().getHarga();
    }
    return res;
  }

  String cekUang() {
    return Integer.toString(this.uang);
  }

  // Setter and Getter dan lengkapi modifier
  String getNama() {
    return this.nama;
  }

  void setNama(String nama) {
    this.nama = nama;
  }

  int getUang() {
    return this.uang;
  }

  void setUang(int uang) {
    this.uang = uang;
  }

  Order[] getKeranjang() {
    return keranjang;
  }

  void resetKeranjang() {
    this.keranjang = new Order[1];
  }

  void decrementKapasitas(int bobot) {
    this.kapasitasKeranjang -= bobot;
  }

  Order[] enlargeList(Order[] arr) {
    // Source: https://stackoverflow.com/questions/8438879/expanding-an-array
    // set new temp array with enlarged size
    Order[] tempArr = new Order[arr.length + 1];
    // copy the entire arr to tempArr
    System.arraycopy(arr, 0, tempArr, 0, arr.length);
    // return enlarged array and copied from curent array
    return tempArr;
  }
}
